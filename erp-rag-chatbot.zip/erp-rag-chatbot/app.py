import streamlit as st

import config
from agent import generate_response
from services import vector_store

# ------------------------------------------------------------------
# Page Configuration
# ------------------------------------------------------------------

st.set_page_config(
    page_title="ERP Migration Orchestrator",
    page_icon="🤖",
    layout="wide",
)

# ------------------------------------------------------------------
# Sidebar
# ------------------------------------------------------------------

with st.sidebar:
    st.title("⚙️ Settings")

    model_name = st.text_input("Model", value=config.CHAT_MODEL)

    temperature = st.slider(
        "Temperature", min_value=0.0, max_value=1.0, value=0.3, step=0.1
    )

    top_k = st.slider(
        "Chunks retrieved (top_k)", min_value=1, max_value=15, value=config.TOP_K
    )

    if st.button("🗑 Clear Conversation"):
        st.session_state.messages = []
        st.rerun()

    st.divider()

    st.markdown("### 📚 Knowledge Base")
    try:
        stats = vector_store.collection_stats()
        if stats["exists"]:
            st.success(f"{stats['points_count']} chunks indexed")
        else:
            st.warning(
                "No collection found yet. Run the ingestion pipeline first:\n\n"
                "`python -m ingestion.ingest_pdfs`"
            )
    except Exception as e:
        st.error(f"Could not reach Qdrant: {e}")

    st.divider()

    st.markdown(
        """
    ### About

    ERP SAGE DB assistant can help with:

    - Finding relevant SAGE tables and field names
    - Explaining what a field means and which table it belongs to
    - Supporting migration mapping decisions

    Retrieval-augmented: every answer is grounded in your indexed
    SAGE DB documentation. Human validation is always required before
    making migration decisions.
    """
    )

st.title("🤖 ERP Migration Orchestrator")

st.caption(
    "Ask questions related to SAP, SAGE, ERP systems, migration, mappings, "
    "and business processes."
)

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        sources = message.get("sources")
        if sources:
            with st.expander(f"📎 {len(sources)} source(s)"):
                for s in sources:
                    st.markdown(
                        f"**{s['source']}** — page {s['page']} "
                        f"_(relevance: {s['score']:.2f})_"
                    )
                    st.text(
                        s["content"][:400] + ("…" if len(s["content"]) > 400 else "")
                    )
                    st.divider()

if prompt := st.chat_input("Ask an ERP-related question..."):

    with st.chat_message("user"):
        st.markdown(prompt)

    st.session_state.messages.append({"role": "user", "content": prompt})

    chat_history = st.session_state.messages[:-1]

    with st.chat_message("assistant"):
        with st.spinner("Searching documentation and generating answer..."):
            result = generate_response(
                prompt=prompt,
                model_name=model_name,
                chat_history=chat_history,
                temperature=temperature,
                top_k=top_k,
            )

        st.markdown(result["answer"])

        if result["sources"]:
            with st.expander(f"📎 {len(result['sources'])} source(s)"):
                for s in result["sources"]:
                    st.markdown(
                        f"**{s['source']}** — page {s['page']} "
                        f"_(relevance: {s['score']:.2f})_"
                    )
                    st.text(
                        s["content"][:400] + ("…" if len(s["content"]) > 400 else "")
                    )
                    st.divider()

    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": result["answer"],
            "sources": result["sources"],
        }
    )

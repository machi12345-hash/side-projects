# services/retrieval.py

"""
Query-time retrieval: embed the user's question and search Qdrant for the
most relevant chunks. This is the only function agent.py needs to call.
"""

import logging
from typing import List, Dict, Optional

import config
from services.embeddings import get_embedding
from services import vector_store

logger = logging.getLogger(__name__)


def retrieve_context(
    query: str,
    top_k: int = None,
    score_threshold: float = None,
    source_filter: Optional[str] = None,
) -> List[Dict]:
    """
    Embed `query` and return the top_k most similar chunks from Qdrant.

    Each result dict has: content, source, page, chunk_index, score.
    Returns an empty list if the query is empty or nothing is found.
    """
    if not query or not query.strip():
        return []

    top_k = top_k or config.TOP_K
    score_threshold = (
        config.SCORE_THRESHOLD if score_threshold is None else score_threshold
    )

    try:
        query_vector = get_embedding(query)
    except Exception:
        logger.exception("Failed to embed query")
        return []

    try:
        hits = vector_store.search(
            query_vector=query_vector,
            top_k=top_k,
            score_threshold=score_threshold,
            source_filter=source_filter,
        )
    except Exception:
        logger.exception("Vector search failed")
        return []

    return hits

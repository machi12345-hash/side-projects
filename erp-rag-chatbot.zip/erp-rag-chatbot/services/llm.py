# services/llm.py

import logging

from openai import OpenAI, APIError, APIConnectionError

import config

logger = logging.getLogger(__name__)

client = OpenAI(
    base_url=config.OPENAI_BASE_URL,
    api_key=config.OPENAI_API_KEY,
)


def ask_llm(
    messages: list,
    model_name: str = None,
    temperature: float = 0.2,
) -> str:
    """Send a chat-completion request and return the assistant's text reply."""
    model_name = model_name or config.CHAT_MODEL

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=temperature,
        )
        return response.choices[0].message.content

    except (APIError, APIConnectionError) as e:
        logger.exception("LLM request failed")
        raise RuntimeError(f"LLM request failed: {e}") from e

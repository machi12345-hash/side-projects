# services/vector_store.py

"""
Qdrant vector store wrapper.

Handles:
- connecting to either a remote Qdrant server (QDRANT_URL) or an embedded
  on-disk instance (QDRANT_PATH) -- no server required to get started.
- creating the collection with the right vector size/distance metric.
- upserting chunks in batches.
- similarity search with metadata payload (source, page, content).

Keeping this in its own module means agent.py / retrieval.py never talk to
Qdrant directly -- if you swap vector DBs later, this is the only file that
needs to change.
"""

import logging
from typing import List, Dict, Any, Optional

from qdrant_client import QdrantClient
from qdrant_client.http import models as qmodels
from qdrant_client.http.exceptions import UnexpectedResponse

import config

logger = logging.getLogger(__name__)

_client: Optional[QdrantClient] = None


def get_client() -> QdrantClient:
    """Return a singleton Qdrant client (remote if QDRANT_URL is set, else local on-disk)."""
    global _client

    if _client is not None:
        return _client

    if config.QDRANT_URL:
        logger.info("Connecting to Qdrant at %s", config.QDRANT_URL)
        _client = QdrantClient(
            url=config.QDRANT_URL,
            api_key=config.QDRANT_API_KEY,
        )
    else:
        logger.info("Using embedded on-disk Qdrant at %s", config.QDRANT_PATH)
        _client = QdrantClient(path=config.QDRANT_PATH)

    return _client


def ensure_collection(vector_size: int, recreate: bool = False) -> None:
    """
    Make sure the target collection exists with the correct vector size.
    Call this once before ingesting, with the actual embedding dimension.
    """
    client = get_client()
    collection_name = config.QDRANT_COLLECTION

    exists = client.collection_exists(collection_name)

    if exists and recreate:
        logger.info("Recreating collection '%s'", collection_name)
        client.delete_collection(collection_name)
        exists = False

    if not exists:
        logger.info(
            "Creating collection '%s' (dim=%d, distance=COSINE)",
            collection_name, vector_size
        )
        client.create_collection(
            collection_name=collection_name,
            vectors_config=qmodels.VectorParams(
                size=vector_size,
                distance=qmodels.Distance.COSINE,
            ),
        )
        # Payload indexes make metadata filtering (e.g. by source doc) fast.
        client.create_payload_index(
            collection_name=collection_name,
            field_name="source",
            field_schema=qmodels.PayloadSchemaType.KEYWORD,
        )


def upsert_chunks(
    ids: List[str],
    vectors: List[List[float]],
    payloads: List[Dict[str, Any]],
    batch_size: int = 100,
) -> None:
    """Upsert chunks into the collection in batches."""
    client = get_client()
    collection_name = config.QDRANT_COLLECTION

    total = len(ids)
    for i in range(0, total, batch_size):
        batch_points = [
            qmodels.PointStruct(
                id=ids[j],
                vector=vectors[j],
                payload=payloads[j],
            )
            for j in range(i, min(i + batch_size, total))
        ]
        client.upsert(collection_name=collection_name, points=batch_points)
        logger.info("Upserted %d/%d points", min(i + batch_size, total), total)


def search(
    query_vector: List[float],
    top_k: int = 5,
    score_threshold: float = 0.0,
    source_filter: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Run a similarity search and return a list of
    {content, source, page, score} dicts, best match first.
    """
    client = get_client()
    collection_name = config.QDRANT_COLLECTION

    query_filter = None
    if source_filter:
        query_filter = qmodels.Filter(
            must=[
                qmodels.FieldCondition(
                    key="source",
                    match=qmodels.MatchValue(value=source_filter),
                )
            ]
        )

    try:
        results = client.query_points(
            collection_name=collection_name,
            query=query_vector,
            limit=top_k,
            score_threshold=score_threshold or None,
            query_filter=query_filter,
            with_payload=True,
        ).points
    except UnexpectedResponse as e:
        logger.error("Qdrant query failed: %s", e)
        return []

    hits = []
    for point in results:
        payload = point.payload or {}
        hits.append({
            "content": payload.get("content", ""),
            "source": payload.get("source", "unknown"),
            "page": payload.get("page", "?"),
            "chunk_index": payload.get("chunk_index", 0),
            "score": point.score,
        })

    return hits


def collection_stats() -> Dict[str, Any]:
    """Small helper used by the UI to show ingestion status."""
    client = get_client()
    collection_name = config.QDRANT_COLLECTION

    if not client.collection_exists(collection_name):
        return {"exists": False, "points_count": 0}

    info = client.get_collection(collection_name)
    return {
        "exists": True,
        "points_count": info.points_count,
        "vector_size": info.config.params.vectors.size,
    }

# services/embeddings.py

"""
Thin wrapper around the OpenAI-compatible embeddings endpoint.

Provides:
- get_embedding(text)          -> single embedding vector
- get_embeddings(texts)        -> batched embeddings (much faster for ingestion)

Both retry transiently-failing requests and raise a clear error if the
embeddings endpoint is unreachable or misconfigured.
"""

import logging
import time
from typing import List

from openai import OpenAI, APIError, APIConnectionError

import config

logger = logging.getLogger(__name__)

client = OpenAI(
    base_url=config.OPENAI_BASE_URL,
    api_key=config.OPENAI_API_KEY,
)

# Most embedding endpoints (and this one, most likely) cap how many inputs
# can be sent in a single request. 32 is a conservative default that works
# almost everywhere; lower it if your endpoint complains.
BATCH_SIZE = 32
MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2.0


def _embed_batch(texts: List[str]) -> List[List[float]]:
    last_err = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = client.embeddings.create(
                model=config.EMBEDDING_MODEL,
                input=texts,
            )
            # Preserve input order (API guarantees index-ordered results).
            ordered = sorted(response.data, key=lambda d: d.index)
            return [item.embedding for item in ordered]

        except (APIError, APIConnectionError) as e:
            last_err = e
            logger.warning(
                "Embedding request failed (attempt %d/%d): %s",
                attempt, MAX_RETRIES, e
            )
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)

    raise RuntimeError(
        f"Failed to get embeddings after {MAX_RETRIES} attempts: {last_err}"
    )


def get_embedding(text: str) -> List[float]:
    """Embed a single piece of text (e.g. a user query)."""
    if not text or not text.strip():
        raise ValueError("Cannot embed empty text.")
    return _embed_batch([text])[0]


def get_embeddings(texts: List[str], batch_size: int = BATCH_SIZE) -> List[List[float]]:
    """
    Embed many texts at once, batching requests for efficiency.
    Used during ingestion where we may have thousands of chunks.
    """
    if not texts:
        return []

    all_embeddings: List[List[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        embeddings = _embed_batch(batch)
        all_embeddings.extend(embeddings)
        logger.info(
            "Embedded %d/%d chunks",
            min(i + batch_size, len(texts)), len(texts)
        )

    return all_embeddings

# ingestion/ingest_pdfs.py

"""
End-to-end ingestion pipeline:

    PDFs in knowledge/  ->  page-level text extraction
                         ->  chunking (chunking.py)
                         ->  embeddings (services/embeddings.py)
                         ->  upsert into Qdrant (services/vector_store.py)

Run it directly:

    python -m ingestion.ingest_pdfs
    python -m ingestion.ingest_pdfs --recreate   # wipe & rebuild the collection
    python -m ingestion.ingest_pdfs --from-cache  # reuse knowledge_chunks.json
                                                    # instead of re-reading PDFs

A JSON cache of the extracted page text is also written to
knowledge_chunks.json purely for debugging/inspection -- it is not read by
the chatbot at query time anymore (Qdrant is the source of truth for that).
"""

import argparse
import hashlib
import json
import logging
import sys
from pathlib import Path
from typing import List, Dict

from pypdf import PdfReader

sys.path.append(str(Path(__file__).resolve().parent.parent))

import config
from ingestion.chunking import chunk_pages
from services.embeddings import get_embeddings
from services import vector_store

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def extract_pages(knowledge_dir: Path = config.KNOWLEDGE_DIR) -> List[Dict]:
    """Extract raw text per PDF page. Returns [{source, page, content}, ...]."""
    pages = []
    pdf_files = sorted(knowledge_dir.glob("*.pdf"))

    if not pdf_files:
        logger.warning("No PDF files found in %s", knowledge_dir)
        return pages

    for pdf_file in pdf_files:
        logger.info("Extracting %s", pdf_file.name)
        try:
            reader = PdfReader(str(pdf_file))
        except Exception as e:
            logger.error("Failed to open %s: %s", pdf_file.name, e)
            continue

        for page_num, page in enumerate(reader.pages, start=1):
            try:
                text = page.extract_text()
            except Exception as e:
                logger.warning(
                    "Failed to extract text from %s page %d: %s",
                    pdf_file.name, page_num, e
                )
                continue

            if not text or not text.strip():
                continue

            pages.append({
                "source": pdf_file.name,
                "page": page_num,
                "content": text,
            })

    return pages


def make_chunk_id(source: str, page: int, chunk_index: int) -> str:
    """
    Deterministic ID so re-running ingestion on the same source doc
    overwrites (rather than duplicates) its old vectors.
    """
    raw = f"{source}::{page}::{chunk_index}"
    # Qdrant point IDs must be an unsigned int or a UUID -- derive a stable
    # UUID from the content key so re-ingestion is idempotent.
    return str(hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32])


def run_ingestion(
    from_cache: bool = False,
    recreate: bool = False,
) -> None:
    if from_cache and config.CHUNKS_CACHE_FILE.exists():
        logger.info("Loading page text from cache: %s", config.CHUNKS_CACHE_FILE)
        with open(config.CHUNKS_CACHE_FILE, "r", encoding="utf-8") as f:
            pages = json.load(f)
    else:
        pages = extract_pages()
        if not pages:
            logger.error(
                "No page text extracted and no cache available. "
                "Put PDF files in %s and try again.", config.KNOWLEDGE_DIR
            )
            return

        with open(config.CHUNKS_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(pages, f, ensure_ascii=False, indent=2)
        logger.info("Cached %d extracted pages to %s", len(pages), config.CHUNKS_CACHE_FILE)

    chunks = chunk_pages(pages)
    logger.info("Split %d pages into %d chunks", len(pages), len(chunks))

    if not chunks:
        logger.error("No chunks to embed. Aborting.")
        return

    texts = [c["content"] for c in chunks]

    logger.info("Embedding %d chunks (model=%s)...", len(texts), config.EMBEDDING_MODEL)
    embeddings = get_embeddings(texts)

    vector_size = len(embeddings[0])
    logger.info("Detected embedding dimension: %d", vector_size)

    vector_store.ensure_collection(vector_size=vector_size, recreate=recreate)

    ids = [
        make_chunk_id(c["source"], c["page"], c["chunk_index"])
        for c in chunks
    ]

    vector_store.upsert_chunks(ids=ids, vectors=embeddings, payloads=chunks)

    logger.info("Ingestion complete. %d chunks indexed in Qdrant collection '%s'.",
                len(chunks), config.QDRANT_COLLECTION)


def main():
    parser = argparse.ArgumentParser(description="Ingest PDFs into Qdrant.")
    parser.add_argument(
        "--from-cache", action="store_true",
        help="Reuse the cached knowledge_chunks.json instead of re-reading PDFs.",
    )
    parser.add_argument(
        "--recreate", action="store_true",
        help="Drop and recreate the Qdrant collection before ingesting.",
    )
    args = parser.parse_args()

    run_ingestion(from_cache=args.from_cache, recreate=args.recreate)


if __name__ == "__main__":
    main()

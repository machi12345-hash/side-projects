# ingestion/chunking.py

"""
Splits raw page text into overlapping, embedding-sized chunks.

Why chunk further than "one PDF page = one chunk"?
- Some pages (e.g. dense SAGE DB table descriptions) are long enough that
  cramming them into a single embedding vector dilutes the vector's ability
  to represent any one field/table clearly, hurting retrieval precision.
- Some pages are very short (headers, page breaks) and are cheap to merge
  with neighbours -- but we keep it simple and just skip near-empty pages.

We use a simple recursive-ish splitter: try to break on paragraph boundaries
first, then sentence-ish boundaries, then hard character windows -- with a
character overlap between consecutive chunks so context isn't lost at the
seams (important here since table rows can span a chunk boundary).
"""

from typing import List

import config

SEPARATORS = ["\n\n", "\n", ". ", " "]


def _split_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)

        # If we're not at the very end of the text, try to end the chunk on
        # a natural boundary (paragraph/sentence/word) instead of mid-token.
        if end < text_len:
            best_break = -1
            for sep in SEPARATORS:
                idx = text.rfind(sep, start, end)
                if idx != -1 and idx > start:
                    best_break = idx + len(sep)
                    break
            if best_break != -1:
                end = best_break

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= text_len:
            break

        # Move the window forward, backing up by `overlap` chars so
        # consecutive chunks share context.
        start = max(end - overlap, start + 1)

    return chunks


def chunk_page(
    content: str,
    chunk_size: int = None,
    overlap: int = None,
) -> List[str]:
    """Split one page's raw text into a list of chunk strings."""
    chunk_size = chunk_size or config.CHUNK_SIZE
    overlap = overlap or config.CHUNK_OVERLAP

    content = content.strip()
    if not content:
        return []

    return _split_text(content, chunk_size, overlap)


def chunk_pages(pages: List[dict]) -> List[dict]:
    """
    Take a list of {source, page, content} page-level dicts (as produced by
    PDF extraction) and return a flat list of chunk-level dicts:
    {source, page, chunk_index, content}.
    """
    all_chunks = []

    for page in pages:
        pieces = chunk_page(page["content"])
        for i, piece in enumerate(pieces):
            all_chunks.append({
                "source": page["source"],
                "page": page["page"],
                "chunk_index": i,
                "content": piece,
            })

    return all_chunks

# ERP Migration Orchestrator — RAG Chatbot

A retrieval-augmented chatbot over SAGE DB / ERP documentation, using
Qdrant as the vector store and your OpenAI-compatible embeddings + chat
endpoint.

## What changed from the previous version

The old setup extracted PDF text into `knowledge_chunks.json` and searched
it with plain keyword matching (`search.py`) — `retrieval.py` and Qdrant
were never actually wired up, and `agent.py` had a couple of bugs (it
referenced `SYSTEM_PROMPT` without importing it, and called the keyword
search instead of any vector search).

This version is a proper RAG pipeline end to end:

- **Real chunking** (`ingestion/chunking.py`): pages are split into
  ~1200-character overlapping chunks on natural boundaries, instead of
  embedding an entire PDF page as one vector. This matters a lot here since
  some SAGE table-description pages are dense and long — one vector per
  page blurs together many unrelated fields.
- **Qdrant vector store** (`services/vector_store.py`): chunks are embedded
  and upserted into a Qdrant collection. Works with an embedded, on-disk
  Qdrant out of the box (no server to install) or a real Qdrant
  server/Docker/Cloud instance if you set `QDRANT_URL`.
- **Idempotent ingestion**: each chunk gets a deterministic ID derived from
  `(source, page, chunk_index)`, so re-running ingestion updates existing
  vectors instead of duplicating them.
- **Batched, retrying embeddings** (`services/embeddings.py`): ingestion
  embeds in batches of 32 with retry/backoff instead of one request per
  chunk.
- **Fixed agent** (`agent.py`): now actually calls vector retrieval, cites
  sources with relevance scores, and clearly tells the model (and the user)
  when nothing relevant was found instead of silently hallucinating.
- **Citations in the UI** (`app.py`): every answer shows an expandable
  "sources" panel with the document, page, and relevance score used to
  generate it. The sidebar also shows how many chunks are currently
  indexed, so you can tell at a glance if ingestion hasn't been run yet.

## Project structure

```
.
├── app.py                     # Streamlit chat UI
├── agent.py                   # Orchestration: retrieve -> prompt -> LLM
├── config.py                  # All settings, read from .env
├── requirements.txt
├── .env.example                # copy to .env and fill in
├── knowledge/                  # put your source PDFs here
├── prompts/
│   └── system_prompt.py
├── services/
│   ├── embeddings.py           # batched embeddings w/ retry
│   ├── llm.py                  # chat completion wrapper
│   ├── retrieval.py            # embed query -> Qdrant search
│   └── vector_store.py         # Qdrant client, collection mgmt, search
└── ingestion/
    ├── chunking.py              # page text -> overlapping chunks
    └── ingest_pdfs.py           # PDFs -> chunks -> embeddings -> Qdrant
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# edit .env: confirm OPENAI_BASE_URL / OPENAI_API_KEY are correct
```

By default Qdrant runs embedded and on-disk at `./qdrant_data` — nothing
else to install. If you'd rather run a real Qdrant server:

```bash
docker run -p 6333:6333 -v $(pwd)/qdrant_storage:/qdrant/storage qdrant/qdrant
```

and set `QDRANT_URL=http://localhost:6333` in `.env`.

## 1. Ingest your documentation

Put your PDFs in `knowledge/`, then run:

```bash
python -m ingestion.ingest_pdfs
```

This extracts text per page, chunks it, embeds every chunk, and upserts it
into the Qdrant collection (`sage_db_docs` by default). A cache of the raw
extracted page text is also written to `knowledge_chunks.json` for
debugging — the chatbot itself no longer reads that file at query time.

Useful flags:

```bash
# Rebuild from scratch (drops the existing collection first)
python -m ingestion.ingest_pdfs --recreate

# Re-chunk/re-embed from the cached knowledge_chunks.json instead of
# re-reading the PDFs (handy if you already have the JSON cache and just
# changed CHUNK_SIZE/CHUNK_OVERLAP)
python -m ingestion.ingest_pdfs --from-cache
```

You already have an existing `knowledge_chunks.json` with ~2,800 extracted
pages from a previous run — drop it in the project root and run with
`--from-cache` to skip re-reading the PDFs entirely.

## 2. Run the chatbot

```bash
streamlit run app.py
```

The sidebar shows how many chunks are currently indexed. If it says "No
collection found yet," ingestion hasn't been run (or `.env` points at a
different `QDRANT_COLLECTION`/`QDRANT_PATH` than what you ingested into).

## Configuration reference (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `OPENAI_BASE_URL` / `OPENAI_API_KEY` | — | Your OpenAI-compatible endpoint |
| `CHAT_MODEL` | `qwen3.8-27b` | Chat model for answers |
| `EMBEDDING_MODEL` | `qwen3-vl-embedding-8b` | Embedding model |
| `QDRANT_URL` | (empty) | Set to use a remote Qdrant server; leave empty for embedded/on-disk |
| `QDRANT_PATH` | `./qdrant_data` | Where the embedded Qdrant stores data |
| `QDRANT_COLLECTION` | `sage_db_docs` | Collection name |
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | `1200` / `200` | Chunking parameters (characters) |
| `TOP_K` | `5` | Chunks retrieved per query (also adjustable live in the UI) |
| `SCORE_THRESHOLD` | `0.0` | Minimum cosine similarity to keep a result |

## Notes / things worth knowing

- **Security**: `.env` currently contains a live API key from the original
  project files. It's `.gitignore`'d here — rotate that key if this project
  has ever been pushed to a shared/public repo.
- **Embedding dimension**: whatever `EMBEDDING_MODEL` returns is auto-detected
  on first ingestion and used to create the Qdrant collection — you don't
  need to configure it manually unless you want to hardcode it.
- **German text**: the source documents are German-language SAGE DB
  exports. The chunker splits on generic paragraph/sentence boundaries so
  it works regardless of language; no changes needed there.
- **Re-ingesting after edits**: since chunk IDs are deterministic per
  `(source, page, chunk_index)`, editing a PDF and re-running ingestion
  updates the affected vectors. If a chunk *disappears* (e.g. you delete a
  page), its old vector will still linger in Qdrant — run with `--recreate`
  periodically if your source docs change structurally.

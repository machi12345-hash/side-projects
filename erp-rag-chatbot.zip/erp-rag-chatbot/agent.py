import logging
from typing import List, Dict, Optional

import config
from prompts.system_prompt import SYSTEM_PROMPT
from services.retrieval import retrieve_context
from services.llm import ask_llm

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Below this similarity score, retrieved chunks are considered too weak to
# be useful context (tune based on your embedding model's score distribution).
MIN_USEFUL_SCORE = 0.2


def build_context(prompt: str, top_k: int = None) -> tuple[str, List[Dict]]:
    """
    Search the vector store and build a formatted context block for the LLM.
    Returns (formatted_context, raw_results) so the caller can also show
    sources in the UI.
    """
    results = retrieve_context(prompt, top_k=top_k or config.TOP_K)

    if not results:
        return "", []

    context_parts = []
    for i, result in enumerate(results, start=1):
        context_parts.append(
            f"[{i}] Source: {result['source']} (page {result['page']}, "
            f"relevance {result['score']:.2f})\n{result['content']}"
        )

    return "\n\n---\n\n".join(context_parts), results


def generate_response(
    prompt: str,
    model_name: str = None,
    chat_history: Optional[List[Dict]] = None,
    temperature: float = 0.3,
    top_k: int = None,
) -> Dict:
    """
    Generate a grounded response using retrieved SAGE DB documentation.

    Returns a dict: {"answer": str, "sources": List[Dict]} so the UI can
    render citations separately from the answer text.
    """
    model_name = model_name or config.CHAT_MODEL

    try:
        context, sources = build_context(prompt, top_k=top_k)

        if context:
            logger.info("Retrieved %d context chunk(s).", len(sources))
        else:
            logger.info("No relevant context found for this query.")

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        if chat_history:
            # Only pass role/content through -- drop any extra UI-only keys.
            messages.extend(
                {"role": m["role"], "content": m["content"]}
                for m in chat_history
                if m.get("role") in ("user", "assistant")
            )

        if context:
            enhanced_prompt = f"""Retrieved SAGE DB documentation:

{context}

User question:
{prompt}

Instructions:
- Answer using the retrieved documentation above as your primary source.
- If the documentation doesn't contain the answer, say so explicitly rather
  than guessing.
- Cite sources inline like [source, p. X] for specific facts."""
        else:
            enhanced_prompt = f"""No relevant documentation was found for this question.

User question:
{prompt}

Instructions:
- Tell the user you don't have enough information to answer confidently,
  since no matching documentation was retrieved.
- Do not invent an answer."""

        messages.append({"role": "user", "content": enhanced_prompt})

        logger.info("Sending request to model '%s'", model_name)
        answer = ask_llm(messages=messages, model_name=model_name, temperature=temperature)
        logger.info("Response received successfully.")

        return {"answer": answer, "sources": sources}

    except Exception as e:
        logger.exception("Error during response generation")
        return {
            "answer": f"Sorry, something went wrong while generating a response: {e}",
            "sources": [],
        }

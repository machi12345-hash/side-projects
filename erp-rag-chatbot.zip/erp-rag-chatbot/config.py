"""
config.py

Single source of truth for environment/config values.
Everything else in the app should import from here instead of
calling os.getenv() directly, so settings are consistent and
documented in one place.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
KNOWLEDGE_DIR = BASE_DIR / "knowledge"          # source PDFs live here
CHUNKS_CACHE_FILE = BASE_DIR / "knowledge_chunks.json"  # debug/inspection cache

# ---------------------------------------------------------------------------
# LLM / Embeddings API (OpenAI-compatible endpoint)
# ---------------------------------------------------------------------------

OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

CHAT_MODEL = os.getenv("CHAT_MODEL", "qwen3.8-27b")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "qwen3-vl-embedding-8b")

# Dimensionality of the embedding model's output vectors.
# IMPORTANT: this must match what EMBEDDING_MODEL actually returns.
# If you change the embedding model, update this (or leave EMBEDDING_DIM=0
# to auto-detect it once at ingest time).
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "0"))

# ---------------------------------------------------------------------------
# Qdrant
# ---------------------------------------------------------------------------

# If QDRANT_URL is set, we connect to a remote/self-hosted Qdrant server.
# Otherwise we fall back to an embedded, on-disk Qdrant instance at
# QDRANT_PATH -- zero infrastructure required to get started.
QDRANT_URL = os.getenv("QDRANT_URL")            # e.g. http://localhost:6333
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")    # only needed for Qdrant Cloud
QDRANT_PATH = os.getenv("QDRANT_PATH", str(BASE_DIR / "qdrant_data"))

QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "sage_db_docs")

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1200"))       # characters
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))  # characters

# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

TOP_K = int(os.getenv("TOP_K", "5"))
SCORE_THRESHOLD = float(os.getenv("SCORE_THRESHOLD", "0.0"))

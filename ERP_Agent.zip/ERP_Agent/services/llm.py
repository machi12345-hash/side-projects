# services/llm.py

import os

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY")
)

def ask_llm(messages,
            model_name="qwen3.8-27b",
            temperature=0.2):

    response = client.chat.completions.create(
        model=model_name,
        messages=messages,
        temperature=temperature
    )

    return response.choices[0].message.content
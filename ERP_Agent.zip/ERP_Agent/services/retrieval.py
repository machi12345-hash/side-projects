def retrieve_context(query):

    """
    Placeholder until Qdrant is connected.
    """

    return {
        "context": "",
        "sources": []
    }
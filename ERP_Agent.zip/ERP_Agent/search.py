import json

KNOWLEDGE_FILE = "knowledge_chunks.json"


def search_documents(query: str, top_k: int = 5):

    query = query.lower()

    with open(KNOWLEDGE_FILE, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    scored = []

    for chunk in chunks:

        text = chunk["content"].lower()

        score = sum(
            1
            for word in query.split()
            if word in text
        )

        if score > 0:
            scored.append((score, chunk))

    scored.sort(reverse=True, key=lambda x: x[0])

    return [
        item[1]
        for item in scored[:top_k]
    ]
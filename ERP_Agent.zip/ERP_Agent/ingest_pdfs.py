from pathlib import Path
from pypdf import PdfReader
import json

KNOWLEDGE_DIR = Path("knowledge")
OUTPUT_FILE = "knowledge_chunks.json"


def extract_pdfs():

    chunks = []

    for pdf_file in KNOWLEDGE_DIR.glob("*.pdf"):

        print(f"Processing {pdf_file.name}")

        reader = PdfReader(str(pdf_file))

        for page_num, page in enumerate(reader.pages, start=1):

            text = page.extract_text()

            if not text:
                continue

            chunks.append({
                "source": pdf_file.name,
                "page": page_num,
                "content": text
            })

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(chunks, f, indent=2)

    print(f"Saved {len(chunks)} chunks")


if __name__ == "__main__":
    extract_pdfs()
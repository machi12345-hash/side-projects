from search import search_documents

results = search_documents(
    "table hr100"
)

for r in results:

    print()
    print("=" * 50)
    print(r["source"])
    print(f"Page {r['page']}")
    print(r["content"][:500])
import os
import logging
from dotenv import load_dotenv
from openai import OpenAI
from search import search_documents


load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)

client = OpenAI(
    base_url=os.getenv("OPENAI_BASE_URL"),
    api_key=os.getenv("OPENAI_API_KEY")
)




def build_context(prompt: str, top_k: int = 5) -> str:
    """
    Search PDF knowledge chunks and build context
    for the language model.
    """

    results = search_documents(prompt, top_k=top_k)

    if not results:
        return ""

    context_parts = []

    for result in results:

        context_parts.append(
            f"""
Source: {result['source']}
Page: {result['page']}

Content:
{result['content']}
"""
        )

    return "\n\n".join(context_parts)

def generate_response(
    prompt: str,
    model_name: str = "qwen3.8-27b",
    chat_history: list = None,
    temperature: float = 0.3
):
    """
    Generate response using retrieved ERP documentation.
    """

    try:

        context = build_context(prompt)

        logger.info("Retrieved ERP context successfully.")

        messages = [
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            }
        ]

        if chat_history:
            messages.extend(chat_history)

        enhanced_prompt = f"""
User Question:
{prompt}

Retrieved ERP Documentation:

{context}

Instructions:

- Use the documentation above as the primary source.
- If the answer is not present, say:
  "I don't have enough information to answer confidently."
- Cite the source document and page number whenever possible.
"""

        messages.append(
            {
                "role": "user",
                "content": enhanced_prompt
            }
        )

        logger.info(
            "Sending request to model '%s'",
            model_name
        )

        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=temperature
        )

        answer = response.choices[0].message.content

        logger.info("Response received successfully.")

        return answer

    except Exception as e:

        logger.exception("Error during response generation")

        return f"Error: {str(e)}"

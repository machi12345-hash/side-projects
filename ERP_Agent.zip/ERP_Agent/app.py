import streamlit as st
from agent import generate_response

# ------------------------------------------------------------------
# Page Configuration
# ------------------------------------------------------------------

st.set_page_config(
    page_title="ERP Migration Orchestrator",
    page_icon="🤖",
    layout="wide"
)

# ------------------------------------------------------------------
# Sidebar
# ------------------------------------------------------------------

with st.sidebar:
    st.title("⚙️ Settings")

    model_name = st.text_input(
        "Model",
        value="qwen3.8-27b"
    )

    temperature = st.slider(
        "Temperature",
        min_value=0.0,
        max_value=1.0,
        value=0.3,
        step=0.1
    )

    if st.button("🗑 Clear Conversation"):
        st.session_state.messages = []
        st.rerun()

    st.divider()

    st.markdown("""
    ### About

    ERP SAGE DB assistant can assist with:

    - Finding relevant sage tables including field names
    - Explaining meaning of field names and how they relate to specific tables

    Human validation is always required before making migration decisions.
    """)

st.title("🤖 ERP Migration Orchestrator")

st.caption(
    "Ask questions related to SAP, SAGE, ERP systems, migration, mappings, and business processes."
)


if "messages" not in st.session_state:
    st.session_state.messages = []


for message in st.session_state.messages:

    with st.chat_message(message["role"]):
        st.markdown(message["content"])


if prompt := st.chat_input("Ask an ERP-related question..."):

    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)

    # Save user message
    st.session_state.messages.append(
        {
            "role": "user",
            "content": prompt
        }
    )

    # Build history for the agent
    chat_history = st.session_state.messages[:-1]

    # Generate assistant response
    with st.chat_message("assistant"):

        with st.spinner("Analyzing ERP context..."):

            response = generate_response(
                prompt=prompt,
                model_name=model_name,
                chat_history=chat_history,
                temperature=temperature
            )

        st.markdown(response)

    # Save assistant response
    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": response
        }
    )